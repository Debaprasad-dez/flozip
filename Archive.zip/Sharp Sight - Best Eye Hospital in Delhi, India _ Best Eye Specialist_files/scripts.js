jQuery(document).ready(function($) {
  "use strict";

  //Cosgrove Sticky Header Script
  $('.csgve-sticky').sticky ({
    topSpacing: 0,
    zIndex: 4
  });

  $("p:empty").remove();

  // Get Time Value from Contact Form
  $('.wpcf7').each( function() {
    var $clock = $(this);
    $clock.find('#clock-in').change(function(){
      var $val = $clock.find(".clockpicker").val();
      $clock.find("#time-pick").val($val);
    });
  });

  //Cosgrove Navigation Hover Script
  $('.dropdown-list').on({mouseenter: function () {
      $(this).find('ul.dropdown-nav').first().stop(true, true).fadeIn();
    },
    mouseleave: function () {
      $(this).find('ul.dropdown-nav').first().stop(true, true).fadeOut();
    }
  });

  // Navigation active
  $('.dropdown-nav li.active').closest('ul').closest('li').addClass('active');

  // Mean Menu
  var $navmenu = $('header nav');
  var $menu_starts = ($navmenu.data('nav') !== undefined) ? $navmenu.data('nav') : 1199;
  $('header nav').meanmenu({
    meanMenuContainer: '.header-style-two.csgve-header .csgve-navigation-wrap >.container-fluid , .header-style-one.csgve-header >.container-fluid ',
    meanMenuOpen: '<span></span><span></span><span></span>',
    meanMenuClose: '<span></span><span></span>',
    meanExpand: '<i class="fa fa-angle-down"></i>',
    meanContract: '<i class="fa fa-angle-up"></i>',
    meanScreenWidth: $menu_starts,

  });

  //Cosgrove Search Box Script
  $('html').on('click', function(e) {
    $('.close-icon').hide();
    $('.search-icon').show();
    $('.search-link .csgve-search-box').fadeOut(400);
  });
  $('.search-link').on('click', function(e) {
    e.stopPropagation();
    $('.search-link .csgve-search-box').find('input[type="text"]').focus();
  });
  $('.search-link a').on('click', function(e) {
    $('.search-icon').toggle();
    $('.close-icon').toggle();
    $('.search-link .csgve-search-box').fadeToggle(400);
  });

  //Cosgrove Set Equal Height Script
  $('.csgve-item, li.product').matchHeight ({
    property: 'height'
  });


  $(".doctor-style-one .doctors-item").each(function(index) {
    $(this).find(".doctor-contact-info").appendTo( $(this).find(".csgve-image") );
  });
  $('.icon-trigger').on('click', function(e) {
    $(this).parents('.doctors-item').toggleClass('class-trigger');
  });

  $(".doctors-item").mouseleave(function(){
    $('.doctors-item').removeClass('class-trigger');
  });


  //Cosgrove Custom Select Script
  $('select').niceSelect();

  $(window).load(function() {
  //Cosgrove Owl Carousel Slider Script
    $('.owl-carousel').each( function() {
      var $carousel = $(this);
      var $items = ($carousel.data('items') !== undefined) ? $carousel.data('items') : 1;
      var $items_tablet = ($carousel.data('items-tablet') !== undefined) ? $carousel.data('items-tablet') : 1;
      var $items_mobile_landscape = ($carousel.data('items-mobile-landscape') !== undefined) ? $carousel.data('items-mobile-landscape') : 1;
      var $items_mobile_portrait = ($carousel.data('items-mobile-portrait') !== undefined) ? $carousel.data('items-mobile-portrait') : 1;
      $carousel.owlCarousel ({
        loop : ($carousel.data('loop') !== undefined) ? $carousel.data('loop') : true,
        items : $carousel.data('items'),
        margin : ($carousel.data('margin') !== undefined) ? $carousel.data('margin') : 0,
        dots : ($carousel.data('dots') !== undefined) ? $carousel.data('dots') : false,
        nav : ($carousel.data('nav') !== undefined) ? $carousel.data('nav') : false,
        autoplay : ($carousel.data('autoplay') !== undefined) ? $carousel.data('autoplay') : false,
        autoplayTimeout : ($carousel.data('autoplay-timeout') !== undefined) ? $carousel.data('autoplay-timeout') : 5000,
        animateOut : ($carousel.data('animateout') !== undefined) ? $carousel.data('animateout') : false,
        animateIn : ($carousel.data('animatein') !== undefined) ? $carousel.data('animatein') : false,
        mouseDrag : ($carousel.data('mouse-drag') !== undefined) ? $carousel.data('mouse-drag') : false,
        autoWidth : ($carousel.data('auto-width') !== undefined) ? $carousel.data('auto-width') : false,
        autoHeight : ($carousel.data('auto-height') !== undefined) ? $carousel.data('auto-height') : false,
        center : ($carousel.data('center') !== undefined) ? $carousel.data('center') : false,
        navText : ["<div class='slider-no-current'><span class='current-no'></span><span class='total-no'></span></div><span class='current-monials'></span>", "<div class='slider-no-next'></div><span class='next-monials'></span>"],
        responsiveClass: true,
        dotsEachNumber: true,
        responsive : {
          0 : {
            items : $items_mobile_portrait,
          },
          480 : {
            items : $items_mobile_landscape,
          },
          768 : {
            items : $items_tablet,
          },
          1200 : {
            items : $items,
          }
        }
      });
      var totLength = $('.owl-dot', $carousel).length;
      $('.total-no', $carousel).html(totLength);
      $('.current-no', $carousel).html(totLength);
      $carousel.owlCarousel();
      $('.current-no', $carousel).html(1);
      $carousel.on('changed.owl.carousel', function(event) {
        var total_items = event.page.count;
        var currentNum = event.page.index + 1;
        $('.total-no', $carousel ).html(total_items);
        $('.current-no', $carousel).html(currentNum);
      });
    });

    // Match Height Script
    if (screen.width >= 768) {
      var maxheight = 0;
      // Products
      $('ul.products .product').each(function () {
        maxheight = ($(this).height() > maxheight ? $(this).height() : maxheight);
      });
      $('ul.products .product').height(maxheight);
      // Blog
      $('.news-style-one .csgve-blog-post .news-item .news-info-wrap').each(function () {
        maxheight = ($(this).height() > maxheight ? $(this).height() : maxheight);
      });
      $('.news-style-one .csgve-blog-post .news-item .news-info-wrap').height(maxheight);

      // Testimonial
      $('.csgve-testimonials.testimonials-style-one .testimonial-item').each(function () {
        maxheight = ($(this).height() > maxheight ? $(this).height() : maxheight);
      });
      $('.csgve-testimonials.testimonials-style-one .testimonial-item').height(maxheight);
    }

    //Cosgrove Masonry Script
    var $grid = $('.csgve-masonry').isotope ({
      itemSelector: '.masonry-item',
      layoutMode: 'packery',
    });
    var filterFns = {
      ium: function() {
        var name = $(this).find('.name').text();
        return name.match( /ium$/ );
      }
    };
    $('.masonry-filters').on( 'click', 'li a', function() {
      var filterValue = $( this ).attr('data-filter');
      filterValue = filterFns[ filterValue ] || filterValue;
      $grid.isotope({
        filter: filterValue
      });
    });
    $('.masonry-filters').each( function( i, buttonGroup ) {
      var $buttonGroup = $( buttonGroup );
      $buttonGroup.on( 'click', 'li a', function() {
        $buttonGroup.find('.active').removeClass('active');
        $(this).addClass('active');
      });
    });

    //Cosgrove Hover Script
    $('.service-item, .plan-item, .gallery-item, .news-item, li.product, .doctors-item').on({mouseenter: function () {
        $(this).addClass('csgve-hover');
      },
      mouseleave: function () {
        $(this).removeClass('csgve-hover');
      }
    });

    //Cosgrove Swiper Slider Script
    var animEndEv = 'webkitAnimationEnd animationend';
    var swipermw = $('.swiper-container.mousewheel').length ? true : false;
    var swiperkb = $('.swiper-container.keyboard').length ? true : false;
    var swipercentered = $('.swiper-container.center').length ? true : false;
    var swiperautoplay = $('.swiper-container').data('autoplay');
    var swiperinterval = $('.swiper-container').data('interval'),
    swiperinterval = swiperinterval ? swiperinterval : 7000;
    swiperautoplay = swiperautoplay ? swiperinterval : false;

    //Cosgrove Swiper Fadeslides Script
    var autoplay = 5000;
    var swiper = new Swiper('.fadeslides', {
      autoplayDisableOnInteraction: false,
      effect: 'fade',
      speed: 800,
      loop: true,
      paginationClickable: true,
      watchSlidesProgress: true,
      autoplay: autoplay,
      simulateTouch: false,
      arrow : false,
      nextButton: '.swiper-button-next',
      prevButton: '.swiper-button-prev',
      pagination: '.swiper-pagination',
      mousewheelControl: swipermw,
      keyboardControl: swiperkb,
      onSlideChangeStart: function(s) {
        var currentSlide = $(s.slides[s.activeIndex]);
        var elems = currentSlide.find('.animated')
        elems.each(function() {
          var $this = $(this);
          var animationType = $this.data('animation');
          $this.addClass(animationType, 100).on(animEndEv, function() {
            $this.removeClass(animationType);
          });
        });
      },
      onSlideChangeEnd: function(s) {
        var currentSlide = $(s.slides[s.activeIndex]);
      }
    });

  });

  //Cosgrove Parallax Script
  $('.csgve-parallax').jarallax ({
    speed: 0.6,
  })

  // Accordion Active Only One At a Time.
  $('.collapse-others').each(function() {
    var $this = $(this);
    $('.collapse', $this).on('show.bs.collapse', function (e) {
      var all = $this.find('.collapse');
      var actives = $this.find('.collapsing, .collapse.in');
      all.each(function (index, element) {
        $(element).collapse('hide');
      })
      actives.each(function (index, element) {
        $(element).collapse('show');
      })
    });
  });

  // Cosgrove Create dropdown
  $("<select />").insertAfter(".tt_tabs_navigation.events_filter");
    $(".tt_tabs_navigation li a").each(function() {
      var el = $(this);
      $("<option />", {
      "value"   : el.attr("href"),
      "text"    : el.text()
    })
    .appendTo(".timetable_clearfix.tt_tabs select");
    });
    $(".timetable_clearfix.tt_tabs select").change(function() {
    window.location = $(this).find("option:selected").val();
  });

  //Cosgrove Hover Animtion Script
  $('.direction-hover .gallery-item').hoverdir ({
    hoverElem: '.gallery-overlay'
  });

  //Cosgrove Magnific Popup Script
$('.csgve-popup').each( function() {
    var $gg = $(this);
  $gg.magnificPopup ({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    closeMarkup:'<div class="mfp-close" title="%title%"></div>',
    image: {
      verticalFit: true,
      titleSrc: function(item) {
        return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
      }
    },
    gallery: {
      enabled: true,
      arrowMarkup:'<div title="%title%" class="mfp-arrow mfp-arrow-%dir%"></div>',
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
        return element.find('*');
      }
    }
  });
  });

$('.csgve-popup.slider').magnificPopup ({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    closeMarkup:'<div class="mfp-close" title="%title%"></div>',
    image: {
      verticalFit: true,
      titleSrc: function(item) {
        return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
      }
    },
    gallery: {
      enabled: true,
      arrowMarkup:'<div title="%title%" class="mfp-arrow mfp-arrow-%dir%"></div>',
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
        return element.find('*');
      }
    }
  });

  //Csgve Magnific Popup Video Script
  $('.csgve-popup-video').magnificPopup ({
    mainClass: 'mfp-fade',
    type: 'iframe',
    closeMarkup:'<div class="mfp-close" title="%title%"></div>',
    iframe: {
      patterns: {
        youtube: {
          index: 'youtube.com/',
          id: function(url) {
            var m = url.match(/[\\?\\&]v=([^\\?\\&]+)/);
            if ( !m || !m[1] ) return null;
            return m[1];
          },
          src: 'https://www.youtube.com/embed/%id%?autoplay=1'
        },
        vimeo: {
          index: 'vimeo.com/',
          id: function(url) {
            var m = url.match(/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/);
            if ( !m || !m[5] ) return null;
            return m[5];
          },
          src: 'https://player.vimeo.com/video/%id%?autoplay=1'
        }
      }
    }
  });

  //Cosgrove Datepicker Script
  $('.csgve-datepicker').dcalendarpicker();

  //Cosgrove Clockpicker Script
  $('.clockpicker').clockpicker();

  //Cosgrove Counter Script
  $('.csgve-counter').each( function() {
    var $counter = $(this);
    var swiperdelay = $counter.data('delay');
    var swipertime = $counter.data('time');
    $counter.counterUp ({
      delay: swiperdelay,
      time: swipertime,
    });
  });

  //Vitria Responsive Tabs Script
  $('.woocommerce-tabs').responsiveTabs ({
    collapsible: false,
    animation: 'fade',
    duration: 0,
    active: 0,
  });

  //Cosgrove Checkbox Script
  $('.payment_method_cod').change(function() {
    var idx = $(this).index()-1;
    $('.payment_box').slideToggle(400);
  });

  var backtop = $('.csgve-back-top');
  //Cosgrove Floating Sidebar Script
  $(window).scroll(function() {
    var $window = jQuery(window),
    $flotingbar = jQuery('.csgve-floating-sidebar'),
    offset = jQuery('.csgve-mid-wrap').offset(),
    $scrolling = jQuery('.csgve-primary').height(),
    $offsetHeight = jQuery('.csgve-primary').offset(),
    $topHeight = 0;
    if (jQuery('.csgve-floating-sidebar').length > 0) {
      if ($window.width() > 991) {
        if (($window.scrollTop() + $topHeight) > offset.top) {
          if ($window.scrollTop() + $topHeight + $flotingbar.height() + 50 < $offsetHeight.top + $scrolling) {
            $flotingbar.stop().animate ({
              marginTop: ($window.scrollTop() - offset.top) + $topHeight + 26,
            });
          }
          else {
            $flotingbar.stop().animate ({
              marginTop: ($scrolling - $flotingbar.height() - 80) + 26,
            });
          }
        }
        else {
          $flotingbar.stop().animate ({
            marginTop: 0,
          });
        }
      }
      else {
        $flotingbar.css('margin-top', 0);
      }
    }
    //Cosgrove Back Top Script
    var windowposition = $(window).scrollTop();
    if(windowposition + $(window).height() == $(document).height()) {
      backtop.removeClass('active');
    }
    else if (windowposition > 150) {
      backtop.addClass('active');
    }
    else {
      backtop.removeClass('active');
    }

  });

  $('.csgve-back-top a').on('click', function(e) {
    jQuery('body,html').animate ({
      scrollTop: 0
    }, 2000);
    return false;
  });

  //Cosgrove Loader Script
  $('body').jpreLoader ({
    preMainSection: '.csgve-preloader',
    prePerText: '.preloader-percentage-text',
    preBar: '.preloader-bar',
  });

});